import React, { createContext, useReducer } from 'react';

const initialState = {
  users: [],
  employees: [],
  loggedInUser: null,
  tasks: [],
  labors: [],
  userLocation: null,
};

const GlobalContext = createContext(initialState);

const globalReducer = (state, action) => {
  switch (action.type) {
    case 'SET_USERS':
      return {
        ...state,
        users: action.payload,
      };
    case 'SET_EMPLOYEES':
      return {
        ...state,
        employees: action.payload,
      };
    case 'SET_LOGGED_IN_USER':
      return {
        ...state,
        loggedInUser: action.payload,
      };
    case 'SET_TASKS':
      return {
        ...state,
        tasks: action.payload,
      };
    case 'ADD_TASK':
      return {
        ...state,
        tasks: [...state.tasks, action.payload],
      };
    case 'UPDATE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(task =>
          task.id === action.payload.id ? action.payload : task
        ),
      };
    case 'SET_LABORS':
      return {
        ...state,
        labors: action.payload,
      };
    case 'ADD_LABOR':
      return {
        ...state,
        labors: [...state.labors, action.payload],
      };
    case 'UPDATE_LABOR':
      return {
        ...state,
        labors: state.labors.map(labor =>
          labor.id === action.payload.id ? action.payload : labor
        ),
      };
    case 'ADD_USER':
      return {
        ...state,
        users: [...state.users, action.payload],
      };
    case 'UPDATE_USER':
      return {
        ...state,
        users: state.users.map(user =>
          user.id === action.payload.id ? action.payload : user
        ),
      };
    case 'DELETE_USER':
      return {
        ...state,
        users: state.users.filter(user => user.id !== action.payload),
      };
    case 'SET_USER_LOCATION':
      return {
        ...state,
        userLocation: action.payload,
      };
    default:
      return state;
  }
};

const GlobalProvider = ({ children }) => {
  const [state, dispatch] = useReducer(globalReducer, initialState);

  const setUsers = (users) => {
    dispatch({ type: 'SET_USERS', payload: users });
  };

  const setEmployees = (employees) => {
    dispatch({ type: 'SET_EMPLOYEES', payload: employees });
  };

  const setLoggedInUser = (user) => {
    dispatch({ type: 'SET_LOGGED_IN_USER', payload: user });
  };

  const setTasks = (tasks) => {
    dispatch({ type: 'SET_TASKS', payload: tasks });
  };

  const addTask = (task) => {
    dispatch({ type: 'ADD_TASK', payload: task });
  };

  const updateTask = (task) => {
    dispatch({ type: 'UPDATE_TASK', payload: task });
  };

  const setLabors = (labors) => {
    dispatch({ type: 'SET_LABORS', payload: labors });
  };

  const addLabor = (labor) => {
    dispatch({ type: 'ADD_LABOR', payload: labor });
  };

  const updateLabor = (labor) => {
    dispatch({ type: 'UPDATE_LABOR', payload: labor });
  };

  const addUser = (user) => {
    dispatch({ type: 'ADD_USER', payload: user });
  };

  const updateUser = (user) => {
    dispatch({ type: 'UPDATE_USER', payload: user });
  };

  const deleteUser = (userId) => {
    dispatch({ type: 'DELETE_USER', payload: userId });
  };

  const setUserLocation = (location) => {
    dispatch({ type: 'SET_USER_LOCATION', payload: location });
  };

  return (
    <GlobalContext.Provider value={{
      ...state,
      setUsers,
      setEmployees,
      setLoggedInUser,
      setTasks,
      addTask,
      updateTask,
      setLabors,
      addLabor,
      updateLabor,
      addUser,
      updateUser,
      deleteUser,
      setUserLocation,
    }}>
      {children}
    </GlobalContext.Provider>
  );
};

export { GlobalContext, GlobalProvider };