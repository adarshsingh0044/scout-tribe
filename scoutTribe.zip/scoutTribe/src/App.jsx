import React, { useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { GlobalProvider, GlobalContext } from './GlobalState';
import AdminDashboard from './components/AdminDashboard';
import HRDashboard from './components/HRDashboard';
import LaborDashboard from './components/LaborDashboard';
import SalesManagerDashboard from './components/SalesManagerDashboard';
import Login from './components/Login';

const ProtectedRoute = ({ children, role }) => {
  const { loggedInUser } = useContext(GlobalContext);
  if (!loggedInUser || (loggedInUser.role !== role && loggedInUser.role !== 'admin')) {
    return <Navigate to="/" />;
  }
  return children;
};

function App() {
  return (
    <GlobalProvider>
      <Router>
        <Routes>
          <Route path="/admin-dashboard" element={<ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>} />
          <Route path="/hr" element={<ProtectedRoute role="hr"><HRDashboard /></ProtectedRoute>} />
          <Route path="/labor" element={<ProtectedRoute role="labor"><LaborDashboard /></ProtectedRoute>} />
          <Route path="/sales-manager" element={<ProtectedRoute role="sales-manager"><SalesManagerDashboard /></ProtectedRoute>} />
          <Route path="/" element={<Login />} />
        </Routes>
      </Router>
    </GlobalProvider>
  );
}

export default App;