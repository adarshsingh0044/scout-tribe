// components/HR/HRDashboard.js
import React, { useContext, useEffect, useState } from 'react';
import { GlobalContext } from '../GlobalState';
import './HRDashboard.css'; // Import the CSS file

function HRDashboard() {
  const { employees, labors, tasks } = useContext(GlobalContext);
  const [totalAttendance, setTotalAttendance] = useState(0);
  const [totalSalaries, setTotalSalaries] = useState(0);
  const [laborTasks, setLaborTasks] = useState([]);

  useEffect(() => {
    calculateAttendance();
    calculateSalaries();
    calculateLaborTasks();
  }, [employees, labors, tasks]);

  const calculateAttendance = () => {
    const total = employees.reduce((sum, employee) => sum + (employee.attendance || 0), 0);
    setTotalAttendance(total);
  };

  const calculateSalaries = () => {
    const total = employees.reduce((sum, employee) => sum + (employee.salary || 0), 0);
    setTotalSalaries(total);
  };

  const calculateLaborTasks = () => {
    const tasksByLabor = labors.map(labor => ({
      labor,
      tasks: tasks.filter(task => task.laborId === labor.id),
    }));
    setLaborTasks(tasksByLabor);
  };

  return (
    <div className="hr-dashboard">
      <h2>HR Dashboard</h2>
      <div className="results">
        <p>Total Attendance: {totalAttendance}</p>
        <p>Total Salaries: ${totalSalaries}</p>
      </div>
      <div className="labor-tasks">
        <h3>Labor Tasks</h3>
        {laborTasks.map(({ labor, tasks }) => (
          <div key={labor.id}>
            <h4>{labor.name}</h4>
            <ul>
              {tasks.map(task => (
                <li key={task.id}>{task.description}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

export default HRDashboard;