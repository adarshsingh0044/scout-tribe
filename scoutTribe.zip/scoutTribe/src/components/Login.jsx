import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlobalContext } from '../GlobalState';
import './Login.css'; // Import the CSS file

function Login() {
  const [role, setRole] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignup, setIsSignup] = useState(false);
  const { setUsers, setEmployees, setLoggedInUser, setUserLocation } = useContext(GlobalContext);
  const navigate = useNavigate();

  const handleSignup = () => {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    users.push({ username, email, password, role });
    localStorage.setItem('users', JSON.stringify(users));
    setIsSignup(false);
  };

  const handleLogin = () => {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(user => user.username === username && user.password === password);
    if (user) {
      setUsers(users);
      setLoggedInUser(user); // Set the logged-in user
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
          const location = {
            username: user.username, // Include the username
            role: user.role, // Include the role
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          };
          setUserLocation(location); // Set the user's location
        });
      }
      if (user.role === 'admin') {
        navigate('/admin-dashboard');
      } else if (user.role === 'sales-manager') {
        navigate('/sales-manager');
      } else if (user.role === 'labor') {
        navigate('/labor');
      } else if (user.role === 'hr') {
        navigate('/hr');
      } else {
        alert('Access denied: Invalid role');
      }
    } else {
      alert('Invalid credentials');
    }
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <h2>{isSignup ? 'Sign Up' : 'Login'}</h2>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        {isSignup && (
          <>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <select value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="">Select Role</option>
              <option value="admin">Admin</option>
              <option value="sales-manager">Sales Manager</option>
              <option value="labor">Labor</option>
              <option value="hr">HR Department</option>
            </select>
          </>
        )}
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={isSignup ? handleSignup : handleLogin}>
          {isSignup ? 'Sign Up' : 'Login'}
        </button>
        <button className="switch-button" onClick={() => setIsSignup(!isSignup)}>
          {isSignup ? 'Switch to Login' : 'Switch to Sign Up'}
        </button>
      </div>
    </div>
  );
}

export default Login;