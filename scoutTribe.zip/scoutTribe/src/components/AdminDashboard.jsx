import React, { useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlobalContext } from '../GlobalState';
import './AdminDashboard.css'; 

function AdminDashboard() {
  const { users, addUser, updateUser, deleteUser, userLocation } = useContext(GlobalContext);
  const [newUser, setNewUser] = useState({ id: '', role: '', username: '', password: '' });
  const [isEditing, setIsEditing] = useState(false);
  const [warning, setWarning] = useState('');
  const navigate = useNavigate(); 

  const handleAddUser = () => {
    if (!newUser.username || !newUser.password || !newUser.role) {
      setWarning('Please fill in all fields.');
      return;
    }
    if (isEditing) {
      updateUser(newUser);
      setIsEditing(false);
    } else {
      addUser({ ...newUser, id: Date.now() });
    }
    setNewUser({ id: '', role: '', username: '', password: '' });
    setWarning('');
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewUser({ ...newUser, [name]: value });
  };

  const handleEditUser = (user) => {
    setNewUser(user);
    setIsEditing(true);
  };

  const handleDeleteUser = (userId) => {
    const confirmDelete = window.confirm('Do you really want to delete this user?');
    if (confirmDelete) {
      deleteUser(userId);
    }
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <div className="dashboard-links">
        <button onClick={() => navigate('/hr')}>HR Dashboard</button>
        <button onClick={() => navigate('/labor')}>Labor Dashboard</button>
        <button onClick={() => navigate('/sales-manager')}>Sales Manager Dashboard</button>
      </div>
      <div className="user-form">
        <h3>{isEditing ? 'Edit User' : 'Add New User'}</h3>
        {warning && <p className="warning">{warning}</p>}
        <input
          type="text"
          name="username"
          placeholder="Username"
          value={newUser.username}
          onChange={handleInputChange}
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={newUser.password}
          onChange={handleInputChange}
        />
        <select name="role" value={newUser.role} onChange={handleInputChange}>
          <option value="">Select Role</option>
          <option value="admin">Admin</option>
          <option value="sales-manager">Sales Manager</option>
          <option value="labor">Labor</option>
          <option value="hr">HR Department</option>
        </select>
        <button onClick={handleAddUser}>{isEditing ? 'Update User' : 'Add User'}</button>
      </div>
      <div className="user-list">
        <h3>Users</h3>
        <ul>
          {users.map(user => (
            <li key={user.id}>
              <span>{user.username} ({user.role})</span>
              <button onClick={() => handleEditUser(user)}>Edit</button>
              <button className='Delete' onClick={() => handleDeleteUser(user.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
      {userLocation && (
        <div className="user-location">
          <h3>User Location</h3>
          <p>Username: {userLocation.username} ({userLocation.role})</p>
          <p>Latitude: {userLocation.latitude}</p>
          <p>Longitude: {userLocation.longitude}</p>
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;