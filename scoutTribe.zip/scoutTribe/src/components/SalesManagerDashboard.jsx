// components/SalesManager/SalesManagerDashboard.js
import React, { useContext, useState } from 'react';
import { GlobalContext } from '../GlobalState';
import './SalesManagerDashboard.css'; // Import the CSS file

function SalesManagerDashboard() {
  const { labors, addLabor, updateLabor } = useContext(GlobalContext);
  const [newLabor, setNewLabor] = useState({ id: '', name: '', area: '', inTime: '', outTime: '' });

  const handleAddLabor = () => {
    if (!newLabor.name || !newLabor.area) {
      alert('Please fill in all fields.');
      return;
    }
    addLabor({ ...newLabor, id: Date.now() });
    setNewLabor({ id: '', name: '', area: '', inTime: '', outTime: '' });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewLabor({ ...newLabor, [name]: value });
  };

  const handleInTime = (id) => {
    const labor = labors.find(l => l.id === id);
    updateLabor({ ...labor, inTime: new Date().toLocaleTimeString() });
  };

  const handleOutTime = (id) => {
    const labor = labors.find(l => l.id === id);
    updateLabor({ ...labor, outTime: new Date().toLocaleTimeString() });
  };

  return (
    <div className="sales-manager-dashboard">
      <h2>Sales Manager Dashboard</h2>
      <div className="labor-form">
        <h3>Add New Labor</h3>
        <input
          type="text"
          name="name"
          placeholder="Labor Name"
          value={newLabor.name}
          onChange={handleInputChange}
        />
        <input
          type="text"
          name="area"
          placeholder="Area"
          value={newLabor.area}
          onChange={handleInputChange}
        />
        <button onClick={handleAddLabor}>Add Labor</button>
      </div>
      <div className="labor-list">
        <h3>Labor List</h3>
        <ul>
          {labors.map(labor => (
            <li key={labor.id}>
              {labor.name} - Area: {labor.area}
              <button onClick={() => handleInTime(labor.id)}>In Time</button>
              <button onClick={() => handleOutTime(labor.id)}>Out Time</button>
              <p>In Time: {labor.inTime}</p>
              <p>Out Time: {labor.outTime}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default SalesManagerDashboard;