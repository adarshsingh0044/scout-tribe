import React, { useContext, useState } from 'react';
import { GlobalContext } from '../GlobalState';
import './LaborDashboard.css'; // Import the CSS file

function LaborDashboard() {
  const { users, tasks, addTask, updateTask } = useContext(GlobalContext);
  const [newTask, setNewTask] = useState({ laborId: '', description: '', completed: false });

  const handleAddTask = () => {
    if (!newTask.laborId || !newTask.description) {
      alert('Please fill in all fields.');
      return;
    }
    addTask({ ...newTask, id: Date.now() });
    setNewTask({ laborId: '', description: '', completed: false });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTask({ ...newTask, [name]: value });
  };

  const handleToggleTaskCompletion = (task) => {
    updateTask({ ...task, completed: !task.completed });
  };

  return (
    <div className="labor-dashboard">
      <h2>Labor Dashboard</h2>
      <div className="task-form">
        <h3>Assign Task to Labor</h3>
        <select name="laborId" value={newTask.laborId} onChange={handleInputChange}>
          <option value="">Select Labor</option>
          {users.filter(user => user.role === 'labor').map(labor => (
            <option key={labor.id} value={labor.id}>{labor.username}</option>
          ))}
        </select>
        <input
          type="text"
          name="description"
          placeholder="Task Description"
          value={newTask.description}
          onChange={handleInputChange}
        />
        <button onClick={handleAddTask}>Assign Task</button>
      </div>
      <div className="task-list">
        <h3>Labor Tasks</h3>
        <ul>
          {tasks.map(task => (
            <li key={task.id}>
              {users.find(user => user.id === task.laborId)?.username}: {task.description}
              <button onClick={() => handleToggleTaskCompletion(task)}>
                {task.completed ? 'Mark Incomplete' : 'Mark Complete'}
              </button>
              <p>Status: {task.completed ? 'Completed' : 'Incomplete'}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default LaborDashboard;